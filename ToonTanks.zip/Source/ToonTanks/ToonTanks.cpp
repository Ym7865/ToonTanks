// Fill out your copyright notice in the Description page of Project Settings.

#include "ToonTanks.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ToonTanks, "ToonTanks" );
